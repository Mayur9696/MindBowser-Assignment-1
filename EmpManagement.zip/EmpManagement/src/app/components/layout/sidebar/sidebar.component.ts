import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  url:any = "/home";

  constructor(private router: Router) {
    router.events.subscribe((url:any) => {
      if(url.url){
        this.url = url.url;
      }
      return url;
    })
  }

  ngOnInit(): void {
  }

}
