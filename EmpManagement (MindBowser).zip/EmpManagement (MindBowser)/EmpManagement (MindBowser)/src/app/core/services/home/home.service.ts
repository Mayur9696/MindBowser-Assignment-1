import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private http: HttpClient) { }

  getUserData():any{
    return this.http.post("/api/getalluser",{});
  }

  getSingleUserData(id):any{
    let frm = new FormData();
    frm.append("email",id);
    return this.http.post("/api/getuser",frm);
  }
  
  deleteSingleUserData(id):any{
    let frm = new FormData();
    frm.append("email",id);
    return this.http.post("/api/delete",frm);
  }

  addSingleUserData(obj):any{
    return this.http.post("/api/add",obj);
  }

  updateSingleUserData(obj):any{
    return this.http.post("/api/update",obj);
  }
}
