import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  loginService(id, pass): any {
    let form = new FormData();
    form.append("email", id);
    form.append("password", pass);
    return this.http.post("/api/login", form);
  }

  register(obj): any {
    return this.http.post("/api/add", obj);
  }
}
