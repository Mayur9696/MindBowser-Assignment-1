import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HomeService } from 'src/app/core/services/home/home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private homeService: HomeService, public dialog: MatDialog) { }

  userData: any = [];

  ngOnInit(): void {
    this.getAllUser();
  }

  getAllUser() {
    this.homeService.getUserData().subscribe(res => {
      if(res.Status){
        this.userData = res.Data;
      }
      
    })
  }

  updateDialog(type, user) {
    let dialogRef = this.dialog.open(AddDialog, {
      data: { type: type, user: user }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === "success") {
        this.getAllUser();
      }
    });
  }

  deletDialog(id) {
    let dialogRef = this.dialog.open(DeleteDialog, {
      data: id
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === "success") {
        this.getAllUser();
      }
    });
  }
}

@Component({
  selector: 'add-dialog',
  templateUrl: 'add-dialog.html',
  styleUrls: ['./home.component.css']
})
export class AddDialog {
  constructor(public dialog: MatDialog, private homeService: HomeService, @Inject(MAT_DIALOG_DATA) public type: any, public dialogRef: MatDialogRef<AddDialog>) {
    if (type.type == "edit") {
      this.data = { ...type.user };
      this.modalType = "edit";
    }
  }

  modalType: any = "new";
  data: any = {
    name: "",
    email: "",
    contact: "",
    password: "",
    confirmPassword: ""
  }

  isError: boolean = false;
  errMsg: any = "";

  setData(e, type) {
    this.data[type] = e.target.value;
  }

  confirmUpdate() {
    if (this.modalType == 'edit') {
      let dialogRef = this.dialog.open(UpdateDialog, {
        data: this.data
      });

      dialogRef.afterClosed().subscribe(result => {
        if(result != 'no'){
          this.closeme(result);
        }
      });
    } else {
      this.homeService.addSingleUserData(this.data).subscribe(res => {
        if (res.status) {
          this.closeme("success");
        } else {
          this.closeme("error");
        }
      });
    }
  }

  closeme(msg) {
    this.dialogRef.close(msg);
  }
}

@Component({
  selector: 'update-dialog',
  templateUrl: 'update-dialog.html',
})
export class UpdateDialog {
  constructor(private homeService: HomeService, @Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<UpdateDialog>) { 
  }

  updateme() {
    this.homeService.deleteSingleUserData(this.data).subscribe(res => {
      if (res.status) {
        this.closeme("success");
      } else {
        this.closeme("error");
      }
    })
  }

  closeme(msg) {
    this.dialogRef.close(msg);
  }
}

@Component({
  selector: 'delete-dialog',
  templateUrl: 'delete-dialog.html',
})
export class DeleteDialog {
  constructor(private homeService: HomeService, @Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<DeleteDialog>) { }

  deleteme() {
    this.homeService.deleteSingleUserData(this.data).subscribe(res => {
      if (res.status) {
        this.closeme("success");
      } else {
        this.closeme("error");
      }
    })
  }

  closeme(msg) {
    this.dialogRef.close(msg);
  }
}
