package com.user.management.system;

import javax.servlet.http.HttpSession;

public class LoginController 
{
	 static public  boolean userValidate(HttpSession session)
	 {
		if(session.getAttribute("email")!=null && session.getAttribute("password")!=null) 
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
}
