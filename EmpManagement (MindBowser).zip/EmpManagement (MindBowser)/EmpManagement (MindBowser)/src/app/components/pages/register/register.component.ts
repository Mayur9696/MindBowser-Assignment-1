import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  data: any = {
    name: "",
    email: "",
    contact: "",
    password: "",
    confirmPassword: ""
  }

  isError:boolean = false;
  errMsg:any = "";

  constructor(private authService: AuthService, private router:Router) { }

  ngOnInit(): void {
  }

  registerUser() {
    console.log(this.data)
    this.authService.register(this.data).subscribe(res => {
      if(res.status){
        this.authService.loginService(this.data.email,this.data.password).subscribe(res => {
          if(res.Status){
            this.router.navigate(['home']);
          } else {
            this.router.navigate(['']);
          }
        })
      } else {
        this.isError = true;
        this.errMsg = res.Message
      }
    })
  }

}
