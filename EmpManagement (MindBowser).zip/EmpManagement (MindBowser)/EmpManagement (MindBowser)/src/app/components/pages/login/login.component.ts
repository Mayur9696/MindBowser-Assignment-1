import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userid:any="";
  password:any="";

  isError:boolean = false;
  errMsg:any = "";

  constructor(private authService: AuthService, private router:Router) { }

  ngOnInit(): void {
  }

  loginUser(){
    this.authService.loginService(this.userid,this.password).subscribe(res => {
      if(res.Status){
        this.router.navigate(['home']);
      } else {
        this.isError = true;
        this.errMsg = res.Message
      }
    })
  }

}
